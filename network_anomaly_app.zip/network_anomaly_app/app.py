from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import pandas as pd
import joblib
import os
from sklearn.preprocessing import LabelEncoder
from collections import Counter

app = Flask(__name__)
app.secret_key = "your_secret_key"

model = joblib.load("model.pkl")


@app.route("/", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username == "cyber" and password == "cyber":
            session["logged_in"] = True
            session["monitoring"] = False
            return redirect(url_for("dashboard"))
        else:
            error = "Invalid credentials"
    return render_template("login.html", error=error)


@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect(url_for("login"))

    monitoring = session.get("monitoring", False)
    packets = []
    anomaly_count = 0
    normal_count = 0
    total_packets = 0

    if monitoring and os.path.exists("network_traffic.csv"):
        try:
            df = pd.read_csv("network_traffic.csv").tail(50)
            le = LabelEncoder()
            df["source_ip_enc"] = le.fit_transform(df["source_ip"])
            df["destination_ip_enc"] = le.fit_transform(df["destination_ip"])
            df["protocol_enc"] = le.fit_transform(df["protocol"])

            features = df[["source_ip_enc", "destination_ip_enc", "protocol_enc", "length"]]
            df["anomaly"] = model.predict(features)
            df["explanation"] = df["anomaly"].apply(
                lambda x: "⚠️ Unusual traffic detected. Pattern doesn't match normal behavior."
                if x == -1 else "✅ Normal traffic pattern."
            )

            # Reason & Risk
            stats = {
                "length_95th": df["length"].quantile(0.95),
                "ip_counts": Counter(df["source_ip"]) + Counter(df["destination_ip"]),
                "protocol_counts": Counter(df["protocol"]),
                "ip_threshold": 3,
                "protocol_threshold": 3
            }

            def determine_reason_and_risk(row):
                reasons = []
                risk = "Low"
                if row["length"] > stats["length_95th"]:
                    reasons.append("📦 Large packet")
                    risk = "Medium"
                if stats["protocol_counts"].get(row["protocol"], 0) < stats["protocol_threshold"]:
                    reasons.append("❗ Rare protocol")
                    risk = "Medium"
                if stats["ip_counts"].get(row["source_ip"], 0) < stats["ip_threshold"]:
                    reasons.append("👤 Unusual source IP")
                    risk = "High"
                if stats["ip_counts"].get(row["destination_ip"], 0) < stats["ip_threshold"]:
                    reasons.append("🎯 Unusual destination IP")
                    risk = "High"
                if not reasons:
                    reasons.append("⚠️ Pattern mismatch")
                return ", ".join(reasons), risk

            df["reason"], df["risk"] = zip(*df.apply(lambda row: determine_reason_and_risk(row) if row["anomaly"] == -1 else ("", ""), axis=1))

            packets = df[["timestamp", "source_ip", "destination_ip", "protocol", "length", "anomaly", "explanation", "reason", "risk"]].to_dict(orient="records")
            anomaly_count = (df["anomaly"] == -1).sum()
            normal_count = (df["anomaly"] == 1).sum()
            total_packets = len(df)

        except Exception as e:
            return f"<h3>Error processing packets: {e}</h3>"

    return render_template("index.html",
                           packets=packets,
                           total_packets=total_packets,
                           anomaly_count=anomaly_count,
                           normal_count=normal_count,
                           monitoring=monitoring)


@app.route("/start-monitoring", methods=["POST"])
def start_monitoring():
    session["monitoring"] = True
    return redirect(url_for("dashboard"))


@app.route("/stop-monitoring", methods=["POST"])
def stop_monitoring():
    session["monitoring"] = False
    return redirect(url_for("dashboard"))


@app.route("/api/packets")
def api_packets():
    if not session.get("logged_in") or not session.get("monitoring"):
        return jsonify({"packets": []})

    try:
        df = pd.read_csv("network_traffic.csv").tail(50)

        le = LabelEncoder()
        df["source_ip_enc"] = le.fit_transform(df["source_ip"])
        df["destination_ip_enc"] = le.fit_transform(df["destination_ip"])
        df["protocol_enc"] = le.fit_transform(df["protocol"])

        features = df[["source_ip_enc", "destination_ip_enc", "protocol_enc", "length"]]
        df["anomaly"] = model.predict(features)
        df["explanation"] = df["anomaly"].apply(
            lambda x: "⚠️ Unusual traffic detected. Pattern doesn't match normal behavior."
            if x == -1 else "✅ Normal traffic pattern."
        )

        stats = {
            "length_95th": df["length"].quantile(0.95),
            "ip_counts": Counter(df["source_ip"]) + Counter(df["destination_ip"]),
            "protocol_counts": Counter(df["protocol"]),
            "ip_threshold": 3,
            "protocol_threshold": 3
        }

        def determine_reason_and_risk(row):
            reasons = []
            risk = "Low"
            if row["length"] > stats["length_95th"]:
                reasons.append("📦 Large packet")
                risk = "Medium"
            if stats["protocol_counts"].get(row["protocol"], 0) < stats["protocol_threshold"]:
                reasons.append("❗ Rare protocol")
                risk = "Medium"
            if stats["ip_counts"].get(row["source_ip"], 0) < stats["ip_threshold"]:
                reasons.append("👤 Unusual source IP")
                risk = "High"
            if stats["ip_counts"].get(row["destination_ip"], 0) < stats["ip_threshold"]:
                reasons.append("🎯 Unusual destination IP")
                risk = "High"
            if not reasons:
                reasons.append("⚠️ Pattern mismatch")
            return ", ".join(reasons), risk

        df["reason"], df["risk"] = zip(*df.apply(lambda row: determine_reason_and_risk(row) if row["anomaly"] == -1 else ("", ""), axis=1))

        packets = df[["timestamp", "source_ip", "destination_ip", "protocol", "length", "anomaly", "explanation", "reason", "risk"]].to_dict(orient="records")
        return jsonify({"packets": packets})

    except Exception as e:
        return jsonify({"error": str(e), "packets": []})


if __name__ == "__main__":
    app.run(debug=True)
