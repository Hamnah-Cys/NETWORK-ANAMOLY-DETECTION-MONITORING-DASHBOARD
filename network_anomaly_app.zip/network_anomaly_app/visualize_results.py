import pandas as pd
import matplotlib.pyplot as plt

# Load the labeled data
df = pd.read_csv("network_traffic_labeled.csv")

# Plot packet length with anomalies in red
plt.figure(figsize=(12, 6))
plt.plot(df.index, df['length'], label='Packet Length', color='blue')
plt.scatter(df[df['anomaly'] == -1].index, df[df['anomaly'] == -1]['length'], color='red', label='Anomaly')

plt.title("📊 Network Packet Length with Anomalies")
plt.xlabel("Packet Number")
plt.ylabel("Length")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
