import pyshark

# Replace with your actual interface name (like 'Wi-Fi' or 'Ethernet')
INTERFACE = 'Wi-Fi'

def capture_packets():
    print(f"🔍 Starting live capture on interface: {INTERFACE}")
    capture = pyshark.LiveCapture(interface=INTERFACE)

    # Capture 20 packets to test
    for packet in capture.sniff_continuously(packet_count=20):
        try:
            print("📦 Packet:")
            print(f"  Protocol: {packet.highest_layer}")
            print(f"  Source IP: {packet.ip.src}")
            print(f"  Destination IP: {packet.ip.dst}")
            print(f"  Length: {packet.length}")
            print("-" * 40)
        except AttributeError:
            # Skip packets that don't have IP layer
            continue

if __name__ == "__main__":
    capture_packets()
