import pyshark
import pandas as pd
from datetime import datetime

INTERFACE = 'Wi-Fi'  # Replace if needed
OUTPUT_FILE = 'network_traffic.csv'

packet_list = []

print("📡 Starting capture... Press Ctrl+C to stop.")

try:
    capture = pyshark.LiveCapture(interface=INTERFACE)
    for packet in capture.sniff_continuously():
        try:
            packet_data = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'source_ip': packet.ip.src,
                'destination_ip': packet.ip.dst,
                'protocol': packet.highest_layer,
                'length': int(packet.length)
            }
            print(packet_data)
            packet_list.append(packet_data)

        except AttributeError:
            continue  # skip packets with missing IP info

except KeyboardInterrupt:
    print("🛑 Capture stopped. Saving to CSV...")

    df = pd.DataFrame(packet_list)
    df.to_csv(OUTPUT_FILE, index=False)
    print(f"✅ Saved {len(df)} packets to '{OUTPUT_FILE}'")
