import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import LabelEncoder
import joblib

# Load captured packet data
df = pd.read_csv("network_traffic.csv")

# Encode categorical columns
le_ip = LabelEncoder()
df['source_ip_enc'] = le_ip.fit_transform(df['source_ip'])
df['destination_ip_enc'] = le_ip.fit_transform(df['destination_ip'])
df['protocol_enc'] = le_ip.fit_transform(df['protocol'])

# Features for model training
features = df[['source_ip_enc', 'destination_ip_enc', 'protocol_enc', 'length']]

# Train the model
model = IsolationForest(contamination=0.1, random_state=42)
model.fit(features)

# Predict anomalies
df['anomaly'] = model.predict(features)

# Save to new file
df.to_csv("network_traffic_labeled.csv", index=False)

# SAVE MODEL
joblib.dump(model, "model.pkl")
print("✅ Model trained and saved as model.pkl")
